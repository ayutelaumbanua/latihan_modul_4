-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2021 at 01:38 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_akademik`
--

-- --------------------------------------------------------

--
-- Table structure for table `calon_mhs`
--

CREATE TABLE `calon_mhs` (
  `nis` varchar(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jk` varchar(10) NOT NULL,
  `telepon` varchar(20) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `calon_mhs`
--

INSERT INTO `calon_mhs` (`nis`, `nama`, `jk`, `telepon`, `alamat`, `foto`) VALUES
('3312012345', 'Budi Setiawan', 'laki-laki', '1234567890', 'Perum. Greenland Blok K9', 'foto1.jpg'),
('3312012397', 'Anwar', 'Laki-Laki', '12345678667', 'Baloi Indah', '51250d8cac28f75cbbcf84729965de1e.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `nidn` char(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `jabatan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`nidn`, `nama`, `alamat`, `jabatan`) VALUES
('4231783762', 'Robertus', 'Kavling Seroja Blok N.11', 'Asisten'),
('3537537', 'Kornelius', 'Nagoya Pardise', 'Lektor');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `kode` varchar(10) NOT NULL,
  `hari` varchar(10) NOT NULL,
  `mata_kuliah` varchar(30) NOT NULL,
  `waktu_mulai` time DEFAULT NULL,
  `waktu_selesai` time DEFAULT NULL,
  `dosen` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`kode`, `hari`, `mata_kuliah`, `waktu_mulai`, `waktu_selesai`, `dosen`) VALUES
('IF221A', 'Senin', 'Statistika', '18:00:00', '18:50:00', 'Sudra Irawan'),
('IF221B', 'Senin', 'Statistika', '18:50:00', '19:40:00', 'Sudra Irawan'),
('IF216A', 'Senin', 'Struktur Data', '19:40:00', '20:30:00', 'Festy Winda Sari'),
('IF216B', 'Senin', 'Prak.Struktur Data', '20:30:00', '21:20:00', 'Festy Winda Sari'),
('IF216C', 'Senin', 'Prak.Struktur Data', '21:20:00', '22:10:00', 'Festy Winda Sari'),
('IF216D', 'Senin', 'Prak.Struktur Data', '22:10:00', '23:00:00', 'Festy Winda Sari'),
('IF217', 'Selasa', 'Dasar Pemograman WEB', '18:50:00', '19:40:00', 'Swono Sibagariang'),
('IF217A', 'Selasa', 'Prak.Dasar Pemograman WEB', '19:40:00', '20:30:00', 'Swono Sibagariang'),
('IF217B', 'Selasa', 'Prak.Dasar Pemograman WEB', '20:30:00', '21:20:00', 'Swono Sibagariang'),
('IF217C', 'Selasa', 'Prak.Dasar Pemograman WEB', '21:20:00', '22:10:00', 'Swono Sibagariang'),
('IF218', 'Rabu', 'Pengantar Basis Data', '18:50:00', '19:40:00', 'Rina Yulius'),
('IF218A', 'Rabu', 'Prak.Pengantar Basis Data', '19:40:00', '20:30:00', 'Rina Yulius'),
('IF218B', 'Rabu', 'Prak.Pengantar Basis Data', '20:30:00', '21:20:00', 'Rina Yulius'),
('IF218C', 'Rabu', 'Prak.Pengantar Basis Data', '21:20:00', '22:10:00', 'Rina Yulius'),
('IF215', 'Kamis', 'RPL1', '18:00:00', '18:50:00', 'Dodi Prima'),
('IF215A', 'Kamis', 'RPL1', '18:50:00', '19:40:00', 'Dodi Prima'),
('IF219', 'Kamis', 'Sistem Operasi ', '19:40:00', '20:30:00', 'Agus Fatulloh'),
('IF219A', 'Kamis', 'Prak.Sistem Operasi', '20:30:00', '21:20:00', 'Agus Fatulloh'),
('IF219B', 'Kamis', 'Prak.Sistem Operasi', '21:20:00', '22:10:00', 'Agus Fatulloh'),
('IF219C', 'Kamis', 'Prak.Sistem Operasi', '22:10:00', '23:00:00', 'Agus Fatulloh'),
('IF220', 'Jumat', 'PBO', '18:50:00', '19:40:00', 'Mira Candra Kirana'),
('IF220A', 'Jumat', 'Prak.PBO', '19:40:00', '20:30:00', 'Mira Candra Kirana'),
('IF220B', 'Jumat', 'Prak.PBO', '20:30:00', '21:30:00', 'Mira Candra Kirana'),
('IF220C', 'Jumat', 'Prak.PBO', '21:20:00', '22:10:00', 'Mira Candra Kirana');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` char(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `jurusan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama`, `alamat`, `jurusan`) VALUES
('3312012345', 'Budi Setiawann', 'Perum. Greenland Blok K9', 'Teknik Informatika'),
('3120837090', 'Dian Grace Wijayanti', 'Kavling Seroja Blok N.199', 'Teknik Elektronika');

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `nik` char(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `bagian` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`nik`, `nama`, `bagian`) VALUES
('3756375', 'Laras Setiawati', 'Administrasi'),
('2743746746', 'Melia Chandra', 'TU');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `nama` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`nama`, `username`, `password`) VALUES
('', 'admin', 'admin\r\n'),
('', 'admin', 'admin\r\n'),
('Anwar', 'admin', '$2y$10$0EEPZSRlqtWXAu20rrBFKOS7qHBMe/LAsgjVh.n/4wQSQvCp.WcG2'),
('Miranda', 'Miranda123', 'miranda123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
