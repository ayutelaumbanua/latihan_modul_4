<?php
// include database connection file
include 'koneksi.php';
$kode= $_POST['kode'];
$hari= $_POST['hari'];
$mata_kuliah= $_POST['mata_kuliah'];
$waktu_mulai=$_POST['waktu_mulai'];
$waktu_selesai=$_POST['waktu_selesai'];
$dosen=$_POST['dosen'];
$result = mysqli_query($koneksi, "UPDATE jadwal SET
hari='$hari',mata_kuliah='$mata_kuliah',waktu_mulai='$waktu_mulai',waktu_selesai='$waktu_selesai',dosen='$dosen' WHERE kode='$kode'");
// Redirect to homepage to display updated user in list
header("Location: jadwalkuliah.php");
?>