<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Menampilkan Data Pegawai</title>
</head>
<body>
    <table border="1">
    	<thead>
            <tr>
            <th>No</th>
            <th>NIK</th>
            <th>Nama Pegawai</th>
            <th>Bagian</th>
        </tr>
</thead>
<tbody>
	<?php 
          include 'koneksi.php';
          $sql = mysqli_query($koneksi, "SELECT * FROM pegawai");
          $no = 1;
          while ($data = mysqli_fetch_array($sql)) {
        ?>
        <tr>
          <td><?php echo $no++;?></td>
          <td><?php echo $data['nik'];?></td>
          <td><?php echo $data['nama'];?></td>
          <td><?php echo $data['bagian'];?></td>
		</tr>
		<?php
	}
	?>
</tbody>
<tr><td><a href="laporanpgw.php">Cetak Data</a></td></tr>
</table>
</body>
</html>