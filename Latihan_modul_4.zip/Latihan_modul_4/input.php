<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Form Upload Gambar</title>
</head>
<body>
<form action="upload.php" method="POST" enctype='multipart/form-data'>
	<table>
		<tr>
			<td>NIS</td>
			<td><input type="text" name="nis" id="nis"></td>
		</tr>
		<tr>
			<td>Nama Siswa</td>
			<td><input type="text" name="nama" id="nama"></td>
		</tr>
		<tr>
			<td>Jenis Kelamin</td>
			<td><input type="radio" name="jk" value="Laki-Laki">Laki-Laki
				<input type="radio" name="jk" value="Perempuan">Perempuan</td>
		</tr>
		<tr>
			<td>Telepon</td>
			<td><input type="text" name="telepon" id="telepon"></td>
		</tr>
		<tr>
			<td>Alamat</td>
			<td><textarea name="alamat"></textarea></td>
		</tr>
		<tr>
			<td><input type="File" name="foto" id="foto"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="simpan" value="Simpan"></td>
		</tr>
	</table>
</form>
</body>
</html>