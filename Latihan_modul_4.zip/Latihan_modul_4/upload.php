<?php 
	
	include 'koneksi.php';
	$nis=$_POST['nis'];
	$nama=$_POST['nama'];
	$jk=$_POST['jk'];
	$telepon=$_POST['telepon'];
	$alamat=$_POST['alamat'];
	$foto=$_FILES['foto']['name'];
	$ukuran_file=$_FILES['foto']['size'];
	$tipe_file=$_FILES['foto']['type'];
	$tmp_file=$_FILES['foto']['tmp_name'];
	$path="image/".$foto;

	if ($tipe_file=="image/jpeg"||$tipe_file=="image/png"){
		if ($ukuran_file<=1000000){
			if (move_uploaded_file($tmp_file, $path)){
			$query="INSERT INTO calon_mhs VALUES('$nis','$nama','$jk','$telepon','$alamat','$foto')";
			$sql=mysqli_query($koneksi,$query);
			if ($sql){
				//header(string)
				echo "Berhasil Upload Gambar";
			}else{
				echo "Terjadi Kesalahan Upload";
				echo "<br><a href='input.php'>Kembali</a>";
			}
		}//jika gambar gagal di upload
	}//jika ukuran lebih besar dari 1 MB
}//jika tipe file buka JPG, JPEG, dan PNG

?>