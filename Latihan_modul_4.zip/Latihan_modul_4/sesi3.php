<?php 
session_start();
$username=$_SESSION["username"];
$password=$_SESSION["password"];
?>
<!DOCTYPE html>
<html>
<body>
<?php 
//Echo variabel sesi yang telah diset di halaman sebelumnya
echo "Username: " .$username. ".<br>";
echo "Password: " . $password. ".";
echo "<h2>Hapus SESSION klik <a href='sesi4.php>di sini";

?>
</body>
</html>