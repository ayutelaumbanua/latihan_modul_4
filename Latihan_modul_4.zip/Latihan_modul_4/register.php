<!DOCTYPE html>
<html>
<head>
	<title>Registrasi </title>
	<style type="text/css">
*{
    margin: 0;
    padding: 0;
    outline: 0;
    font-family: 'Open Sans', sans-serif;
}
body{
    height: 100vh;
    background-image: url(administrasi.jpg);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}

.container{
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%,-50%);
    padding: 20px 30px;
    height: 350px;
    width: 300px;
    background-color: rgba(0,0,0,.4);
    box-shadow: 0 0 3px rgba(255,255,255,.3);
}
.container h1{
    text-align: center;
    color: #fafafa;
    margin-bottom: 30px;
    text-transform: uppercase;
    border-bottom: 4px solid #2979ff;
}
.container label{
    text-align: left;
    color: #ddedfd;
}
.container form input{
    width: calc(100% - 20px);
    padding: 8px 10px;
    margin-bottom: 15px;
    border: none;
    background-color: transparent;
    border-bottom: 2px solid #2c64d0;
   
    font-size: 20px;
}
.container form button{
    width: 100%;
    padding: 5px 0;
    border: none;
    background-color:#2c64d0;
    font-size: 18px;
    color: #fafafa;
}
.error {
	background-color: #d9d4d1;
	width: 400px;
	height: auto;
	margin-top: 20px;
	margin-left: auto;
	margin-right: auto;
	padding: 15px;
	border-radius: 10px;
	color: #000000;

		}
	</style>
</head>
<body>
	<div id="container">
		<div class="container">
		<form action="proses.php" method="POST">
			<h1>Registration</h1>
			<label>Name&ensp;&ensp;&ensp;&ensp; : </label>
	<input type="Text" name="nama"><br>
	<label>Username&ensp;:</label>
	<input type="Text" name="username"><br>
	<label>Password&ensp;:</label>
	<input type="Text" name="password"><br>
			<button type="submit" name="submit" value="simpan">SUBMIT</button>
		</form>
	</div>

		
</body>
</html>