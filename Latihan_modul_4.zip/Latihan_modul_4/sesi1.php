<?php 
// memulai sesi
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?phpcredits()//set variabel sesi
$_SESSION['username'] = "admin";
$_SESSION['password'] = "admin";

echo "Variabel sesi telah diciptakan.";
echo "<h2>Cek SESSION klik <a href='sesi2.php'di sini";
?>
</body>
</html>