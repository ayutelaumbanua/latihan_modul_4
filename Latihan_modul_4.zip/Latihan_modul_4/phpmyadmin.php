<html>
<head>
	<title>PHP GET DAN POST</title>
</head>
<body>
<center><h1>Program Data Mahasiswa Dengan Method GET</h1></center>
<form method="GET" action="tampil.php">
	<table width="350" border="1" align="center" bordercolor="#0000FF">
		<tr>
			<td><strong>NIM</strong></td>
			<td><input type="text" name="nim" id="nim"></td>
		</tr>
		<tr>
			<td width="142"><strong>Nama Mahasiswa</strong></td>
			<td width="181"><input type="text" name="nama" id="nama" /></td>
		</tr>
		<tr>
			<td><strong>Jurusan</strong></td>
			<td><input type="text" name="jurusan" id="jurusan" /></td>
		</tr>
		<tr>
			<td><strong>Nilai</strong></td>
			<td><input type="text" name="nilai" id="nilai" /></td>
		</tr>

	</table>
	<center><input type="submit" name="Submit" value="Tampil" /></center>
</form>
</body>
</html>