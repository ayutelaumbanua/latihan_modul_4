<?php 
include 'koneksi.php';
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];

$pass_acak=password_hash($password, PASSWORD_DEFAULT);
$input = mysqli_query($koneksi,"INSERT INTO user VALUE('$nama','$username','$password')") or die(mysql_error());
if($input){
	echo "Data Berhasil Tersimpan";
	header("location:login.php");
}else{
	echo"Gagal Disimpan";
}
?>