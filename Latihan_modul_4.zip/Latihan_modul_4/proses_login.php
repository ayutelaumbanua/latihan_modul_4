<?php 
session_start();
include 'koneksi.php';
$username=$_POST['username'];
$password=$_POST['password'];
$data=mysqli_query($koneksi,"SELECT * FROM user WHERE username='$username'");
$row=mysqli_fetch_array($data);
if(password_verify($password, $row['password'])){
	if(mysqli_num_rows($data)>0){

		echo "Login Berhasil";
	}
}else{
	echo "Username dan Password Tidak Ada";
}
?>