<?php
include 'koneksi.php';
$kode= $_POST['kode'];
$hari= $_POST['hari'];
$mata_kuliah= $_POST['mata_kuliah'];
$waktu_mulai=$_POST['waktu_mulai'];
$waktu_selesai=$_POST['waktu_selesai'];
$dosen=$_POST['dosen'];
$input = mysqli_query($koneksi,"INSERT INTO jadwal VALUES('$kode','$hari','$mata_kuliah','$waktu_mulai','$waktu_selesai','$dosen')") or die(mysql_error()); if($input){
echo "Data Berhasil Disimpan"; header("location:jadwalkuliah.php");
}else{
echo "Gagal Disimpan";
}
?>
