<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Menampilkan Data Dosen</title>
</head>
<body>
    <table border="1">
    	<thead>
            <tr>
            <th>No</th>
            <th>NIM</th>
            <th>Nama Dosen</th>
            <th>Alamat</th>
            <th>Jabatan</th>
        </tr>
</thead>
<tbody>
	<?php 
          include 'koneksi.php';
          $sql = mysqli_query($koneksi, "SELECT * FROM dosen");
          $no = 1;
          while ($data = mysqli_fetch_array($sql)) {
        ?>
        <tr>
          <td><?php echo $no++;?></td>
          <td><?php echo $data['nidn'];?></td>
          <td><?php echo $data['nama'];?></td>
          <td><?php echo $data['alamat'];?></td>
          <td><?php echo $data['jabatan'];?></td>
		</tr>
		<?php
	}
	?>
</tbody>
<tr><td><a href="laporandsn.php">Cetak Data</a></td></tr>
</table>
</body>
</html>